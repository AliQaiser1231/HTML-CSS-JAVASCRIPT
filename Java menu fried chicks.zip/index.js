console.log("<><><><><><>Fried Chicks<><><><><><>");
console.log("<><><><>Menu<><><><>");
console.log("Welcome to our menu :");
console.log("(1) Pizza")
console.log("(2) Sandwich")
console.log("(3) Shawarma")
console.log("(4) Nuggets")
console.log("(5) Burgers")
console.log("(6) Hotwings")
console.log("(7) Wraps")
console.log("(8) Loaded Fries")
console.log("(9) Pizza Deals with special discount")
console.log("(10) Burger Deals with special discount")
console.log("(0) Exit Menu")
console.log("Enter your Desired Things : ")
console.log("<><><><><><><><><><><><><><><><>")
let n=prompt("Enter Your desired things :");
if(n==1){
    console.log("(1)small")
    console.log("(2)medium")
    console.log("(3)large")
    console.log("<><><><><><><><><><><><><>")
    alert("If ammount is 5000 exceed then we give you 14% discount for Eid-Milad")
    let n=prompt("Enter Size");
    if(n>0&&n<2){
        console.log("Small Pizza = 650")
        console.log("<><><><><><><><><><><>")
      let n=prompt("Enter quantity");
        if(n==1){
            console.log("@@@@@@ Summary @@@@@@")
            console.log("Quantity=1")
            console.log("Total ammount= 650")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
           let n=prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }

        }else if(n==2) {
            console.log("Quantity=2")
            console.log("Total ammount=1300")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==3){
            console.log("Quantity=3")
            console.log("Total ammount=1300")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        } else if(n==4){
            console.log("Quantity=4")
            console.log("Total ammount=2600")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==5){
            console.log("Quantity=5")
            console.log("Total ammount=3250")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==6){
            console.log("Quantity=6")
            console.log("Total ammount=3900")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==7){
            console.log("Quantity=7")
            console.log(" ammount=4550")
            console.log("17% GST = 270")
            console.log("Total ammount =4550+270= 4820")
            console.log("Total ammount with 14% Discount= 4480")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==8){
            console.log("Quantity=8")
            console.log("Total ammount=5200")
            console.log("17% GST = 305 ")
            console.log("Total ammount =5200+305= 5505")
            console.log("Total ammount with 14% Discount= 5300")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==9){
            console.log("Quantity=9")
            console.log("Total ammount=5850")
            console.log("17% GST = 270")
            console.log("Total ammount =5850+340= 6190")
            console.log("Total ammount with 14% Discount= 5950")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==10){
            console.log("Quantity=10")
            console.log("Total ammount=6500")
            console.log("17% GST = 400")
            console.log("Total ammount =6500+400= 6900")
            console.log("Total ammount with 14% Discount= 6750")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }
     }else if(n>1&&n<3){
        console.log("Medium Pizza = 1000")
        console.log("<><><><><><><><><><><>")
        let n=prompt("Enter quantity");
          if(n==1){
              console.log("Quantity=1")
              console.log("Total ammount= 1000")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
             let n=prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
  
          }else if(n==2) {
              console.log("Quantity=2")
              console.log("Total ammount=2000")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==3){
              console.log("Quantity=3")
              console.log("Total ammount=3000")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==4){
              console.log("Quantity=4")
              console.log("Total ammount=4000")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==5){
              console.log("Quantity=5")
              console.log("Total ammount=5000")
              console.log("17% GST = 270")
              console.log("Total ammount =5000+270= 5270")
              console.log("Total ammount with 14% Discount= 5110")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==6){
              console.log("Quantity=6")
              console.log("Total ammount=6000")
              console.log("17% GST = 300")
              console.log("Total ammount =6000+300= 6300")
              console.log("Total ammount with 14% Discount= 6250")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==7){
              console.log("Quantity=7")
              console.log("Total ammount=7000")
              console.log("17% GST = 320")
              console.log("Total ammount =7000+320= 7320")
              console.log("Total ammount with 14% Discount= 7100")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==8){
              console.log("Quantity=8")
              console.log("Total ammount=8000")
              console.log("17% GST = 400")
              console.log("Total ammount =8000+400= 8400")
              console.log("Total ammount with 14% Discount= 8140")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==9){
              console.log("Quantity=9")
              console.log("Total ammount= 9000")
              console.log("17% GST = 490")
              console.log("Total ammount = 9000+490= 9490")
              console.log("Total ammount with 14% Discount= 9110")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==10){
              console.log("Quantity=10")
              console.log("Total ammount= 10,000")
              console.log("17% GST = 550")
              console.log("Total ammount =10,000+550= 10,550")
              console.log("Total ammount with 14% Discount= 10,200")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }
    }else if(n>2&&n<4){  
        console.log("Large Pizza = 1500")
        console.log("<><><><><><><><><><><>")
        let n=prompt("Enter quantity");
          if(n==1){
              console.log("Quantity=1")
              console.log("Total ammount= 1500")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
             let n=prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
  
          }else if(n==2) {
              console.log("Quantity=2")
              console.log("Total ammount=3000")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==3){
              console.log("Quantity=3")
              console.log("Total ammount= 4500")
              console.log("17% GST = 250")
              console.log("Total ammount =4500+250= 4750")
              console.log("Total ammount with 14% Discount= 4590")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          } else if(n==4){
              console.log("Quantity=4")
              console.log("Total ammount=6000")
              console.log("17% GST = 270")
              console.log("Total ammount =6000+270= 6270")
              console.log("Total ammount with 14% Discount= 6100")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==5){
                console.log("Quantity=5")
                console.log("Total ammount=7500")
                console.log("17% GST = 270")
                console.log("Total ammount =7500+270= 7770")
                console.log("Total ammount with 14% Discount= 7600")
                console.log("(1)Online payment")
                console.log("(2) Cash")
                console.log("<><><><><><><><><><>")
                prompt("Enter your choice")
                if(n==1){
                    console.log("<><>Tkank you<><>")
                    console.log("You will recieve order in 30 minutes")
                }else {
                    console.log("You will recieve order in 30 minutes")
                }
          }else if(n==6){
              console.log("Quantity=6")
              console.log("Total ammount= 9000")
              console.log("17% GST = 270")
              console.log("Total ammount =9000+270= 9270")
              console.log("Total ammount with 14% Discount= 9120")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==7){
              console.log("Quantity=7")
              console.log("Total ammount= 10,500")
              console.log("17% GST = 270")
              console.log("Total ammount =10500+270= 10770")
              console.log("Total ammount with 14% Discount= 10600")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==8){
              console.log("Quantity=8")
              console.log("Total ammount= 12000")
              console.log("17% GST = 270")
              console.log("Total ammount =12000+270= 12270")
              console.log("Total ammount with 14% Discount= 12100")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==9){
              console.log("Quantity=9")
              console.log("Total ammount= 13,500")
              console.log("17% GST = 270")
              console.log("Total ammount =13500+270= 13770")
              console.log("Total ammount with 14% Discount= 13550")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==10){
              console.log("Quantity=10")
              console.log("Total ammount=15000")
              console.log("17% GST = 270")
              console.log("Total ammount =15000+270= 15270")
              console.log("Total ammount with 14% Discount= 15100")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
             prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }
    }
}else if(n>1&&n<3){
    console.log("(1) Club sandwith")
    console.log("(2) Chicken sandwith")
    alert("If ammount is 5000 exceed then we give you 14% discount for Eid-Milad")
    let n=prompt("Enter your choice"); 
    if(n>0&&n<2){
        console.log("Club Sandwith = 500")
        console.log("<><><><><><><><><><><>")
      let n=prompt("Enter quantity");
        if(n==1){
            console.log("@@@@@@ Summary @@@@@@")
            console.log("Quantity=1")
            console.log("Total ammount= 500")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
           let n=prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }

        }else if(n==2) {
            console.log("Quantity=2")
            console.log("Total ammount=1000")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==3){
            console.log("Quantity=3")
            console.log("Total ammount=1500")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        } else if(n==4){
            console.log("Quantity=4")
            console.log("Total ammount=2000")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==5){
            console.log("Quantity=5")
            console.log("Total ammount=2500")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==6){
            console.log("Quantity=6")
            console.log("Total ammount=3000")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==7){
            console.log("Quantity=7")
            console.log("Total ammount=3500")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==8){
            console.log("Quantity=8")
            console.log("Total ammount= 4000")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==9){
            console.log("Quantity=9")
            console.log("Total ammount=4500")
            console.log("17% GST = 270")
            console.log("Total ammount =4500+270= 4770")
            console.log("Total ammount with 14% Discount= 4480")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==10){
            console.log("Quantity=10")
            console.log("Total ammount=5000")
            console.log("17% GST = 270")
            console.log("Total ammount = 5000+270= 5270")
            console.log("Total ammount with 14% Discount=5100 ")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }
    }else if(n>1&&n<3){
        console.log("Chicken Sandwith = 400")
        console.log("<><><><><><><><><><><>")
        let n=prompt("Enter quantity");
          if(n==1){
              console.log("Quantity=1")
              console.log("Total ammount= 400")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
             let n=prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
  
          }else if(n==2) {
              console.log("Quantity=2")
              console.log("Total ammount= 800")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==3){
              console.log("Quantity=3")
              console.log("Total ammount= 1200")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          } else if(n==4){
              console.log("Quantity=4")
              console.log("Total ammount= 1600")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==5){
              console.log("Quantity=5")
              console.log("Total ammount= 2000")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==6){
              console.log("Quantity=6")
              console.log("Total ammount= 2400")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==7){
              console.log("Quantity=7")
              console.log("Total ammount= 2800")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==8){
              console.log("Quantity=8")
              console.log("Total ammount= 3200")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==9){
              console.log("Quantity=9")
              console.log("Total ammount= 3600")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==10){
              console.log("Quantity=10")
              console.log("Total ammount= 4000")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }
    }
}else if(n>2&&n<4){
    console.log("(1) Chicken Shawarma")
    console.log("(2) Ziner Shawarma")
    alert("If ammount is 5000 exceed then we give you 14% discount for Eid-Milad")
    let n=prompt("Enter your choice"); 
    if(n>0&&n<2){
        console.log("Chicken Shawarma = 250")
        console.log("<><><><><><><><><><><>")
      let n=prompt("Enter quantity");
        if(n==1){
            console.log("@@@@@@ Summary @@@@@@")
            console.log("Quantity=1")
            console.log("Total ammount= 250")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
           let n=prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }

        }else if(n==2) {
            console.log("Quantity=2")
            console.log("Total ammount= 500")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==3){
            console.log("Quantity=3")
            console.log("Total ammount= 750")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        } else if(n==4){
            console.log("Quantity=4")
            console.log("Total ammount= 1000")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==5){
            console.log("Quantity=5")
            console.log("Total ammount= 1250")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==6){
            console.log("Quantity=6")
            console.log("Total ammount= 1500")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==7){
            console.log("Quantity=7")
            console.log("Total ammount= 1750")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==8){
            console.log("Quantity=8")
            console.log("Total ammount= 2000")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==9){
            console.log("Quantity=9")
            console.log("Total ammount= 2250")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==10){
            console.log("Quantity=10")
            console.log("Total ammount= 2500")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }
    }else if(n>1&&n<3){
        console.log("Zinger Shawarma = 350")
        console.log("<><><><><><><><><><><>")
        let n=prompt("Enter quantity");
          if(n==1){
              console.log("Quantity=1")
              console.log("Total ammount= 350")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
             let n=prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
  
          }else if(n==2) {
              console.log("Quantity=2")
              console.log("Total ammount= 700")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==3){
              console.log("Quantity=3")
              console.log("Total ammount= 1050")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          } else if(n==4){
              console.log("Quantity=4")
              console.log("Total ammount= 1400")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==5){
              console.log("Quantity=5")
              console.log("Total ammount= 1750")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==6){
              console.log("Quantity=6")
              console.log("Total ammount= 2100")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==7){
              console.log("Quantity=7")
              console.log("Total ammount= 2450")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==8){
              console.log("Quantity=8")
              console.log("Total ammount= 2800")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==9){
              console.log("Quantity=9")
              console.log("Total ammount= 3150")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==10){
              console.log("Quantity=10")
              console.log("Total ammount= 3500")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }
    }
}else if(n>3&&n<5){
    console.log("(1) Full Bucket(10 Pcs)")
    console.log("(2) Half Bucket(5 Pcs)")
    alert("If ammount is 5000 exceed then we give you 14% discount for Eid-Milad")
    let n=prompt("Enter your choice"); 
    if(n>0&&n<2){
        console.log("10 Pcs = 600")
        console.log("<><><><><><><><><><><>")
      let n=prompt("Enter quantity");
        if(n==1){
            console.log("@@@@@@ Summary @@@@@@")
            console.log("Quantity=1")
            console.log("Total ammount= 600")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
           let n=prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }

        }else if(n==2) {
            console.log("Quantity=2")
            console.log("Total ammount= 1200")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==3){
            console.log("Quantity=3")
            console.log("Total ammount= 1800")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        } else if(n==4){
            console.log("Quantity=4")
            console.log("Total ammount= 2400")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==5){
            console.log("Quantity=5")
            console.log("Total ammount= 3000")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==6){
            console.log("Quantity=6")
            console.log("Total ammount= 3600")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==7){
            console.log("Quantity=7")
            console.log("Total ammount= 4200")
            console.log("17% GST = 270")
            console.log("Total ammount =4200+270= 4470")
            console.log("Total ammount with 14% Discount= 4100")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==8){
            console.log("Quantity=8")
            console.log("Total ammount= 4800")
            console.log("17% GST = 270")
            console.log("Total ammount =4800+270= 5070")
            console.log("Total ammount with 14% Discount= 4890")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==9){
            console.log("Quantity=9")
            console.log("Total ammount= 5400")
            console.log("17% GST = 270")
            console.log("Total ammount =5400+270= 5670")
            console.log("Total ammount with 14% Discount= 5500")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==10){
            console.log("Quantity=10")
            console.log("Total ammount= 6000")
            console.log("17% GST = 270")
            console.log("Total ammount = 6000+270= 6270")
            console.log("Total ammount with 14% Discount= 6100")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }
    }else if(n>1&&n<3){
        console.log("5 Pcs = 350")
        console.log("<><><><><><><><><><><>")
        let n=prompt("Enter quantity");
          if(n==1){
              console.log("Quantity=1")
              console.log("Total ammount= 350")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
             let n=prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
  
          }else if(n==2) {
              console.log("Quantity=2")
              console.log("Total ammount= 700")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==3){
              console.log("Quantity=3")
              console.log("Total ammount= 1050")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          } else if(n==4){
              console.log("Quantity=4")
              console.log("Total ammount= 1400")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==5){
              console.log("Quantity=5")
              console.log("Total ammount= 1750")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==6){
              console.log("Quantity=6")
              console.log("Total ammount= 2100")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==7){
              console.log("Quantity=7")
              console.log("Total ammount= 2450")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==8){
              console.log("Quantity=8")
              console.log("Total ammount= 2800")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==9){
              console.log("Quantity=9")
              console.log("Total ammount= 3150")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==10){
              console.log("Quantity=10")
              console.log("Total ammount= 3500")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }
    }
}else if(n>4&&n<6){
    console.log("(1) Zinger Burger")
    console.log("(2) patty Burger")
    console.log("(3) Chapli Burger")
    console.log("<><><><><><><><><><><><><>")
    alert("If ammount is 5000 exceed then we give you 14% discount for Eid-Milad")
    let n=prompt("Enter Your Choice");
    if(n>0&&n<2){
        console.log("Zinger Burger = 400")
        console.log("<><><><><><><><><><><>")
      let n=prompt("Enter quantity");
        if(n==1){
            console.log("@@@@@@ Summary @@@@@@")
            console.log("Quantity=1")
            console.log("Total ammount= 400")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
           let n=prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }

        }else if(n==2) {
            console.log("Quantity=2")
            console.log("Total ammount= 800")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==3){
            console.log("Quantity=3")
            console.log("Total ammount= 1200")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        } else if(n==4){
            console.log("Quantity=4")
            console.log("Total ammount= 1600")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==5){
            console.log("Quantity=5")
            console.log("Total ammount= 2000")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==6){
            console.log("Quantity=6")
            console.log("Total ammount= 2400")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==7){
            console.log("Quantity=7")
            console.log("Total ammount= 2800")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==8){
            console.log("Quantity=8")
            console.log("Total ammount= 3200")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==9){
            console.log("Quantity=9")
            console.log("Total ammount= 3600")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==10){
            console.log("Quantity=10")
            console.log("Total ammount= 4000")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }
    }else if(n>1&&n<3){
        console.log("Patty Burger = 350")
        console.log("<><><><><><><><><><><>")
        let n=prompt("Enter quantity");
          if(n==1){
              console.log("Quantity=1")
              console.log("Total ammount= 350")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
             let n=prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
  
          }else if(n==2) {
              console.log("Quantity=2")
              console.log("Total ammount= 700")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==3){
              console.log("Quantity=3")
              console.log("Total ammount= 1050")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          } else if(n==4){
              console.log("Quantity=4")
              console.log("Total ammount= 1400")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==5){
              console.log("Quantity=5")
              console.log("Total ammount= 1750")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==6){
              console.log("Quantity=6")
              console.log("Total ammount= 2100")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==7){
              console.log("Quantity=7")
              console.log("Total ammount= 2450")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==8){
              console.log("Quantity=8")
              console.log("Total ammount= 2800")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==9){
              console.log("Quantity=9")
              console.log("Total ammount= 3150")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==10){
              console.log("Quantity=10")
              console.log("Total ammount= 3500")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }
    }else if(n>2&&n<4){  
        console.log("Chapli Burger = 300")
        console.log("<><><><><><><><><><><>")
        let n=prompt("Enter quantity");
          if(n==1){
              console.log("Quantity=1")
              console.log("Total ammount= 300")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
             let n=prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
  
          }else if(n==2) {
              console.log("Quantity=2")
              console.log("Total ammount= 600")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==3){
              console.log("Quantity=3")
              console.log("Total ammount= 900")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          } else if(n==4){
              console.log("Quantity=4")
              console.log("Total ammount= 1200")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==5){
              console.log("Quantity=5")
              console.log("Total ammount= 1500")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==6){
              console.log("Quantity=6")
              console.log("Total ammount= 1800")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==7){
              console.log("Quantity=7")
              console.log("Total ammount= 2100")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==8){
              console.log("Quantity=8")
              console.log("Total ammount= 2400")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==9){
              console.log("Quantity=9")
              console.log("Total ammount= 2700")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==10){
              console.log("Quantity=10")
              console.log("Total ammount= 3000")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
             prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }
    }
}else if(n>5&&n<7){
    console.log("(1) 10 Pcs")
    console.log("(2) 5 Pcs")
    alert("If ammount is 5000 exceed then we give you 14% discount for Eid-Milad")
    let n=prompt("Enter your choice"); 
    if(n>0&&n<2){
        console.log("10 Pcs = 800")
        console.log("<><><><><><><><><><><>")
      let n=prompt("Enter quantity");
        if(n==1){
            console.log("@@@@@@ Summary @@@@@@")
            console.log("Quantity=1")
            console.log("Total ammount= 800")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
           let n=prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }

        }else if(n==2) {
            console.log("Quantity=2")
            console.log("Total ammount= 1600")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==3){
            console.log("Quantity=3")
            console.log("Total ammount= 2400")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        } else if(n==4){
            console.log("Quantity=4")
            console.log("Total ammount= 3200")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==5){
            console.log("Quantity=5")
            console.log("Total ammount= 4000")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==6){
            console.log("Quantity=6")
            console.log("Total ammount= 4800")
            console.log("17% GST = 270")
            console.log("Total ammount =4800+270= 5070")
            console.log("Total ammount with 14% Discount= 4900")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==7){
            console.log("Quantity=7")
            console.log("Total ammount= 5600")
            console.log("17% GST = 270")
            console.log("Total ammount =5600+270= 5870")
            console.log("Total ammount with 14% Discount= 5700")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==8){
            console.log("Quantity=8")
            console.log("Total ammount= 6400")
            console.log("17% GST = 270")
            console.log("Total ammount = 6400+270= 6670")
            console.log("Total ammount with 14% Discount= 6500")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==9){
            console.log("Quantity=9")
            console.log("Total ammount= 7200")
            console.log("17% GST = 270")
            console.log("Total ammount = 7200+270= 7470")
            console.log("Total ammount with 14% Discount= 7300")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==10){
            console.log("Quantity=10")
            console.log("Total ammount= 8000")
            console.log("17% GST = 270")
            console.log("Total ammount = 8000+270= 8270")
            console.log("Total ammount with 14% Discount= 8150")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }
    }else if(n>1&&n<3){
        console.log("5 Pcs = 400")
        console.log("<><><><><><><><><><><>")
        let n=prompt("Enter quantity");
          if(n==1){
              console.log("Quantity=1")
              console.log("Total ammount= 400")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
             let n=prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
  
          }else if(n==2) {
              console.log("Quantity=2")
              console.log("Total ammount= 800")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==3){
              console.log("Quantity=3")
              console.log("Total ammount= 1200")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          } else if(n==4){
              console.log("Quantity=4")
              console.log("Total ammount= 1600")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==5){
              console.log("Quantity=5")
              console.log("Total ammount= 2000")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==6){
              console.log("Quantity=6")
              console.log("Total ammount= 2400")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==7){
              console.log("Quantity=7")
              console.log("Total ammount= 2800")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==8){
              console.log("Quantity=8")
              console.log("Total ammount= 3200")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==9){
              console.log("Quantity=9")
              console.log("Total ammount= 3600")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==10){
              console.log("Quantity=10")
              console.log("Total ammount= 4000")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }
    }
}else if(n>6&&n<8){
    console.log("(1) Tortila Wrap")
    console.log("(2) Chicken Wrap")
    alert("If ammount is 5000 exceed then we give you 14% discount for Eid-Milad")
    let n=prompt("Enter your choice"); 
    if(n>0&&n<2){
        console.log("Tortila Wrap = 1000")
        console.log("<><><><><><><><><><><>")
      let n=prompt("Enter quantity");
        if(n==1){
            console.log("@@@@@@ Summary @@@@@@")
            console.log("Quantity=1")
            console.log("Total ammount= 1000")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
           let n=prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }

        }else if(n==2) {
            console.log("Quantity=2")
            console.log("Total ammount= 2000")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==3){
            console.log("Quantity=3")
            console.log("Total ammount= 3000")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        } else if(n==4){
            console.log("Quantity=4")
            console.log("Total ammount= 4000")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==5){
            console.log("Quantity=5")
            console.log("Total ammount= 5000")
            console.log("17% GST = 270")
            console.log("Total ammount = 5000+270= 5270")
            console.log("Total ammount with 14% Discount= 5120")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==6){
            console.log("Quantity=6")
            console.log("Total ammount= 6000")
            console.log("17% GST = 270")
            console.log("Total ammount = 6000+270= 6270")
            console.log("Total ammount with 14% Discount= 6130")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==7){
            console.log("Quantity=7")
            console.log("Total ammount= 7000")
            console.log("17% GST = 270")
            console.log("Total ammount = 7000+270= 7270")
            console.log("Total ammount with 14% Discount= 7130")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==8){
            console.log("Quantity=8")
            console.log("Total ammount= 8000")
            console.log("17% GST = 270")
            console.log("Total ammount = 8000+270= 8270")
            console.log("Total ammount with 14% Discount= 8140")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==9){
            console.log("Quantity=9")
            console.log("Total ammount= 9000")
            console.log("17% GST = 270")
            console.log("Total ammount = 9000+270= 9270")
            console.log("Total ammount with 14% Discount= 9150")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==10){
            console.log("Quantity=10")
            console.log("Total ammount= 10,000")
            console.log("17% GST = 270")
            console.log("Total ammount = 10000+270= 10,270")
            console.log("Total ammount with 14% Discount= 10,120")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }
    }else if(n>1&&n<3){
        console.log("Chicken Wrap = 800")
        console.log("<><><><><><><><><><><>")
        let n=prompt("Enter quantity");
          if(n==1){
              console.log("Quantity=1")
              console.log("Total ammount= 800")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
             let n=prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
  
          }else if(n==2) {
              console.log("Quantity=2")
              console.log("Total ammount= 1600")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==3){
              console.log("Quantity=3")
              console.log("Total ammount= 2400")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          } else if(n==4){
              console.log("Quantity=4")
              console.log("Total ammount= 3200")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==5){
              console.log("Quantity=5")
              console.log("Total ammount= 4000")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==6){
              console.log("Quantity=6")
              console.log("Total ammount= 4800")
              console.log("17% GST = 270")
              console.log("Total ammount = 4800+270= 5070")
              console.log("Total ammount with 14% Discount= 4910")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==7){
              console.log("Quantity=7")
              console.log("Total ammount= 5600")
              console.log("17% GST = 270")
              console.log("Total ammount = 5600+270= 5870")
              console.log("Total ammount with 14% Discount= 5720")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==8){
              console.log("Quantity=8")
              console.log("Total ammount= 6400")
              console.log("17% GST = 270")
              console.log("Total ammount = 6400+270=6670")
              console.log("Total ammount with 14% Discount= 6510")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==9){
              console.log("Quantity=9")
              console.log("Total ammount= 7200")
              console.log("17% GST = 270")
              console.log("Total ammount = 7200+270= 7470")
              console.log("Total ammount with 14% Discount= 7300")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==10){
              console.log("Quantity=10")
              console.log("Total ammount= 8000")
              console.log("17% GST = 270")
              console.log("Total ammount = 8000+270= 8270")
              console.log("Total ammount with 14% Discount= 8100")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }
    }
}else if(n>7&&n<9){
    console.log("(1) Large loaded Fries")
    console.log("(2) Small loaded Fries")
    alert("If ammount is 5000 exceed then we give you 14% discount for Eid-Milad")
    let n=prompt("Enter your choice"); 
    if(n>0&&n<2){
        console.log("Large loaded Fries = 500")
        console.log("<><><><><><><><><><><>")
      let n=prompt("Enter quantity");
        if(n==1){
            console.log("@@@@@@ Summary @@@@@@")
            console.log("Quantity=1")
            console.log("Total ammount= 500")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
           let n=prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }

        }else if(n==2) {
            console.log("Quantity=2")
            console.log("Total ammount=1000")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==3){
            console.log("Quantity=3")
            console.log("Total ammount=1500")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        } else if(n==4){
            console.log("Quantity=4")
            console.log("Total ammount=2000")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==5){
            console.log("Quantity=5")
            console.log("Total ammount=2500")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==6){
            console.log("Quantity=6")
            console.log("Total ammount=3000")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==7){
            console.log("Quantity=7")
            console.log("Total ammount=3500")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==8){
            console.log("Quantity=8")
            console.log("Total ammount= 4000")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==9){
            console.log("Quantity=9")
            console.log("Total ammount=4500")
            console.log("17% GST = 270")
            console.log("Total ammount =4500+270= 4770")
            console.log("Total ammount with 14% Discount= 4620")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==10){
            console.log("Quantity=10")
            console.log("Total ammount=5000")
            console.log("17% GST = 270")
            console.log("Total ammount = 5000+270= 5270")
            console.log("Total ammount with 14% Discount= 5120")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }
    }else if(n>1&&n<3){
        console.log("Small loaded Fries = 400")
        console.log("<><><><><><><><><><><>")
        let n=prompt("Enter quantity");
          if(n==1){
              console.log("Quantity=1")
              console.log("Total ammount= 400")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
             let n=prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
  
          }else if(n==2) {
              console.log("Quantity=2")
              console.log("Total ammount= 800")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==3){
              console.log("Quantity=3")
              console.log("Total ammount= 1200")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          } else if(n==4){
              console.log("Quantity=4")
              console.log("Total ammount= 1600")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==5){
              console.log("Quantity=5")
              console.log("Total ammount= 2000")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==6){
              console.log("Quantity=6")
              console.log("Total ammount= 2400")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==7){
              console.log("Quantity=7")
              console.log("Total ammount= 2800")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==8){
              console.log("Quantity=8")
              console.log("Total ammount= 3200")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==9){
              console.log("Quantity=9")
              console.log("Total ammount= 3600")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==10){
              console.log("Quantity=10")
              console.log("Total ammount= 4000")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }
    }
}else if(n>8&&n<10){
    console.log("(1) Party Deal")
    console.log("(2) Super Value Deal")
    console.log("(3) Summer Deal")
    console.log("<><><><><><><><><><><><><>")
    alert("If ammount is 5000 exceed then we give you 14% discount for Eid-Milad")
    let n=prompt("Enter Your Choice");
    if(n>0&&n<2){
        console.log("Party Deal = 4500")
        console.log("Party Deal = 3500 With 10% Discount")
        console.log("Deal Contain :")
        console.log("1 Large Pizza")
        console.log("1 Small Pizza")
        console.log("10 hotwings")
        console.log("1.5 Ltr Drink")
        console.log("<><><><><><><><><><><>")
      let n=prompt("Enter quantity");
        if(n==1){
            console.log("@@@@@@ Summary @@@@@@")
            console.log("Quantity=1")
            console.log("Total ammount= 3500")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
           let n=prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }

        }else if(n==2) {
            console.log("Quantity=2")
            console.log("Total ammount= 7000")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==3){
            console.log("Quantity=3")
            console.log("Total ammount= 10,500")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        } else if(n==4){
            console.log("Quantity=4")
            console.log("Total ammount= 14000")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==5){
            console.log("Quantity=5")
            console.log("Total ammount= 17,500")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==6){
            console.log("Quantity=6")
            console.log("Total ammount= 21000")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==7){
            console.log("Quantity=7")
            console.log("Total ammount= 24,500")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==8){
            console.log("Quantity=8")
            console.log("Total ammount= 28000")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==9){
            console.log("Quantity=9")
            console.log("Total ammount= 31,500")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==10){
            console.log("Quantity=10")
            console.log("Total ammount= 35,000")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }
    }else if(n>1&&n<3){
        console.log("Super value Deal = 2500")
        console.log("Super value  Deal With Discount = 2000")
        console.log("Deal Contain :")
        console.log("2 Small Pizza")
        console.log("5 Hotwings")
        console.log("1 Zinger Burger ")
        console.log("1.5 Ltr Drink")
        console.log("<><><><><><><><><><><>")
        let n=prompt("Enter quantity");
          if(n==1){
              console.log("Quantity=1")
              console.log("Total ammount= 2000")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
             let n=prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
  
          }else if(n==2) {
              console.log("Quantity=2")
              console.log("Total ammount= 4000")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==3){
              console.log("Quantity=3")
              console.log("Total ammount= 6000")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          } else if(n==4){
              console.log("Quantity=4")
              console.log("Total ammount= 8000")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==5){
              console.log("Quantity=5")
              console.log("Total ammount= 10,000")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==6){
              console.log("Quantity=6")
              console.log("Total ammount= 12000")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==7){
              console.log("Quantity=7")
              console.log("Total ammount= 14000")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==8){
              console.log("Quantity=8")
              console.log("Total ammount= 16000")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==9){
              console.log("Quantity=9")
              console.log("Total ammount= 18000")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==10){
              console.log("Quantity=10")
              console.log("Total ammount= 20,000")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }
    }else if(n>2&&n<4){  
        console.log("Summer Deal = 1500")
        console.log("Summer Deal with Discount = 1000")
        console.log("Deal contain :")
        console.log("2 small Pizza")
        console.log("1.5 Ltr Drink")
        console.log("<><><><><><><><><><><>")
        let n=prompt("Enter quantity");
          if(n==1){
              console.log("Quantity=1")
              console.log("Total ammount= 1000")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
             let n=prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
  
          }else if(n==2) {
              console.log("Quantity=2")
              console.log("Total ammount= 2000")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==3){
              console.log("Quantity=3")
              console.log("Total ammount= 3000")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          } else if(n==4){
              console.log("Quantity=4")
              console.log("Total ammount= 4000")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==5){
              console.log("Quantity=5")
              console.log("Total ammount= 5000")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==6){
              console.log("Quantity=6")
              console.log("Total ammount= 6000")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==7){
              console.log("Quantity=7")
              console.log("Total ammount= 7000")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==8){
              console.log("Quantity=8")
              console.log("Total ammount= 8000")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==9){
              console.log("Quantity=9")
              console.log("Total ammount= 9000")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==10){
              console.log("Quantity=10")
              console.log("Total ammount= 10,000")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
             prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }
    }
}else if(n>9&&n<11){
    console.log("(1) Student Deal ")
    console.log("(2) Patty Deal")
    console.log("<><><><><><><><><><><><><>")
    alert("If ammount is 5000 exceed then we give you 14% discount for Eid-Milad")
    let n=prompt("Enter Your Choice");
    if(n>0&&n<2){
        console.log("Student Deal = 1200")
        console.log("Student Deal = 1000 With 10% Discount")
        console.log("Deal Contain :")
        console.log("3 Zinger Burger")
        console.log("1 Reg Salad ")
        console.log("1.5 Ltr Drink")
        console.log("<><><><><><><><><><><>")
      let n=prompt("Enter quantity");
        if(n==1){
            console.log("@@@@@@ Summary @@@@@@")
            console.log("Quantity=1")
            console.log("Total ammount= 1000")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
           let n=prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }

        }else if(n==2) {
            console.log("Quantity=2")
            console.log("Total ammount= 2000")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==3){
            console.log("Quantity=3")
            console.log("Total ammount= 3000")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        } else if(n==4){
            console.log("Quantity=4")
            console.log("Total ammount= 4000")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==5){
            console.log("Quantity=5")
            console.log("Total ammount= 5000")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==6){
            console.log("Quantity=6")
            console.log("Total ammount= 6000")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==7){
            console.log("Quantity=7")
            console.log("Total ammount= 7000")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==8){
            console.log("Quantity=8")
            console.log("Total ammount= 8000")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==9){
            console.log("Quantity=9")
            console.log("Total ammount= 9000")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }else if(n==10){
            console.log("Quantity=10")
            console.log("Total ammount= 10,000")
            console.log("(1)Online payment")
            console.log("(2) Cash")
            console.log("<><><><><><><><><><>")
            prompt("Enter your choice")
            if(n==1){
                console.log("<><>Tkank you<><>")
                console.log("You will recieve order in 30 minutes")
            }else {
                console.log("You will recieve order in 30 minutes")
            }
        }
    }else if(n>1&&n<3){
        console.log("Patty Deal = 1700")
        console.log("Patty Deal With Discount = 1500")
        console.log("Deal Contain :")
        console.log("5 Patty burger")
        console.log("1.5 Ltr Drink")
        console.log("<><><><><><><><><><><>")
        let n=prompt("Enter quantity");
          if(n==1){
              console.log("Quantity=1")
              console.log("Total ammount= 1500")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
             let n=prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
  
          }else if(n==2) {
              console.log("Quantity=2")
              console.log("Total ammount= 3000")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==3){
              console.log("Quantity=3")
              console.log("Total ammount= 4500")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          } else if(n==4){
              console.log("Quantity=4")
              console.log("Total ammount= 6000")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==5){
              console.log("Quantity=5")
              console.log("Total ammount= 7500")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==6){
              console.log("Quantity=6")
              console.log("Total ammount= 9000")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==7){
              console.log("Quantity=7")
              console.log("Total ammount= 10,500")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==8){
              console.log("Quantity=8")
              console.log("Total ammount= 12000")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==9){
              console.log("Quantity=9")
              console.log("Total ammount= 13500")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }else if(n==10){
              console.log("Quantity=10")
              console.log("Total ammount= 15,000")
              console.log("(1)Online payment")
              console.log("(2) Cash")
              console.log("<><><><><><><><><><>")
              prompt("Enter your choice")
              if(n==1){
                  console.log("<><>Tkank you<><>")
                  console.log("You will recieve order in 30 minutes")
              }else {
                  console.log("You will recieve order in 30 minutes")
              }
          }
    }
}else if(n>-1&&n<1){
    console.log("(Thank You for coming Into Fried Chicks.Com)")
    console.log("We hope to see you again")
    console.log("- - - Fried chicks.Com - - -")
    console.log("111 000 777")
}





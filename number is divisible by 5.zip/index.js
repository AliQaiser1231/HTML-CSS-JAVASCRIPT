let number = prompt("Enter number divisible by 5")
if(number%5==0){
    console.log("number is divisible");
}else{
    console.log("number is not divisible by 5")
}


